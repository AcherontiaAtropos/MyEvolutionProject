public class TilePosition {
    public int x;
    public int y;

    public TilePosition (int x, int y){
        this.x = x; this.y = y;
    }

}
