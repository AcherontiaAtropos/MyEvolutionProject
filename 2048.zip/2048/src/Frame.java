import java.util.Set;
import java.util.TreeSet;

public class Frame extends AbstractBoardClass{

    private final int size;
    private final int routeLength;
    private int numberOfTiles = 0;
    Set<Integer> tiles = new TreeSet<>();
    private Tile [] [] board ;// = new Tile[size][size];

    public Frame (int size, int numberOfTiles) {
        this.size = size;
        this.routeLength = 4 * (size - 1);
        this.board = new Tile[size][size];

        if (numberOfTiles > routeLength) numberOfTiles = routeLength;


        while (this.tiles.size()<numberOfTiles){
            Integer tileNumber = MyRand.getRandomNumberInRange(0, routeLength);

            TilePosition tilePosition = parseNumberToPosition(tileNumber);

            this.board[tilePosition.x][tilePosition.y] = new Tile(0);
            this.tiles.add(tileNumber);
        }
    }

    public void turnFrame(){
    Set<Integer> newTiles = new TreeSet<>();
        for(Integer tile: this.tiles) {
            removeTile(parseNumberToPosition(tile));
            newTiles.add((tile+1)%(routeLength-1));
        }
        for(Integer tile: newTiles){
            addTile(parseNumberToPosition(tile), new Tile (0));
        }
        this.tiles = newTiles;
    }

    private TilePosition parseNumberToPosition (int number){
        try{
            if (routeLength <= number){
                throw new IllegalArgumentException();
            }
        }catch (IllegalArgumentException ex){
            System.out.println("ERROR, number to big");
            return null;
        }

        if (number < size-1)    return new TilePosition(0, number);
        else if (number < (size-1)*2) return  new TilePosition( number - (size - 1), size - 1);
        else if (number < (size-1)*3) return  new TilePosition(size - 1, 3*(size - 1) - number);
        else return new TilePosition(4*(size-1)-number, 0);
    }



    @Override
    Tile getTile(TilePosition tp) {
        return this.board[tp.x][tp.y];
    }

    @Override
    int getSize() {
        return this.size;
    }

    void removeTile(TilePosition tp) {
        this.board[tp.x][tp.y] = null;
    }
    void addTile(TilePosition tp, Tile tile) {
        this.board[tp.x][tp.y] = tile;
    }
}
