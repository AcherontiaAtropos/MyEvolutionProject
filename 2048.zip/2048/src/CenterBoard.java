import java.util.Random;

public class CenterBoard extends AbstractBoardClass{

    private int size = 4;
    private int score = 0;
    private int tilesOnBoard = 0;
    private Frame frame;
    private  Tile [] [] board = new Tile [size][size];

    public CenterBoard (int size){
        this.frame = frame;
        this.size = size;
    }

    public CenterBoard (int size, Frame frame){
        this.frame = frame;
        this.size = size;
    }

    @Override
    public int getSize(){return size;}

    @Override
    public Tile getTile (TilePosition tp){
        return this.board [tp.x][tp.y];
    }

    public int getScore(){
        return this.score;
    }

    public void insertTile (Tile tile, TilePosition tilePosition){
        this.board[tilePosition.x][tilePosition.y] = tile;
        tilesOnBoard ++;
        if (tile.getValue()>this.score) this.score = tile.getValue();
    }
    public void removeTile (TilePosition tilePosition){
        this.board[tilePosition.x][tilePosition.y] = null;
        tilesOnBoard --;
    }

    public boolean addRandomTile (int tileValue)
    throws GameOverException {
        if (tilesOnBoard == size * size) {
            throw new GameOverException("Can't add another tile");
        }
            Tile newTile = new Tile(tileValue);
            while (true) {
                int x = MyRand.getRandomNumberInRange(0, 4);
                int y = MyRand.getRandomNumberInRange(0, 4);
                TilePosition tp = new TilePosition(x, y);
                if (this.getTile(tp) == null) {
                    this.insertTile(newTile, tp);
                    return true;
                }
            }
        }


    public void makeGameMove (Arrow arrow) throws GameOverException {
        switch (arrow){
            case UP: makeGameMoveUp(); break;
            case LEFT: makeGameMoveLeft(); break;
            case DOWN: makeGameMoveDown(); break;
            case RIGHT: makeGameMoveRight();break;
        }
        try {
            int newTileValue = MyRand.getRandomNumberInRange(1,3)*2;
            addRandomTile(newTileValue);
            } catch (GameOverException e) {
            throw e;
        }
    }

    public void makeGameMoveLeft(){
        for (int rowNo = 0; rowNo<size; rowNo ++){

            Tile lastSeenTile = null;
            int movedTilesPosition = -1;

            int i = -1;
            while (i<size-1){
                i++;
                TilePosition thisPosition = new TilePosition(rowNo, i);
                Tile thisField = this.getTile(thisPosition);
                if (thisField == null) continue;
                this.removeTile(thisPosition);

                if (lastSeenTile!= null && thisField.value == lastSeenTile.value){
                    this.insertTile(new Tile(thisField.value*2), new TilePosition(rowNo, movedTilesPosition));
                    tilesOnBoard --;
                    i = movedTilesPosition;
                    lastSeenTile = null;
                }
                else{
                    movedTilesPosition += 1;
                    this.insertTile(new Tile(thisField.value), new TilePosition(rowNo, movedTilesPosition));
                    lastSeenTile = thisField;
                }
            }
        }
    }

    public void makeGameMoveRight(){
        for (int rowNo = 0; rowNo<size; rowNo ++){

            Tile lastSeenTile = null;
            int movedTilesPosition = size;

            int i = size;
            while (i>0){
                i--;
                TilePosition thisPosition = new TilePosition(rowNo, i);
                Tile thisField = this.getTile(thisPosition);
                if (thisField == null) continue;
                this.removeTile(thisPosition);

                if (lastSeenTile!= null && thisField.value == lastSeenTile.value){
                    this.insertTile(new Tile(thisField.value*2), new TilePosition(rowNo, movedTilesPosition));
                    tilesOnBoard --;
                    i = movedTilesPosition;
                    lastSeenTile = null;
                }
                else{
                    movedTilesPosition -= 1;
                    this.insertTile(new Tile(thisField.value), new TilePosition(rowNo, movedTilesPosition));
                    lastSeenTile = thisField;
                }
            }
        }
    }

    public void makeGameMoveDown(){
        for (int ColNo = 0; ColNo<size; ColNo ++){

            Tile lastSeenTile = null;
            int movedTilesPosition = size;

            int i = size;
            while (i>0){
                i--;
                TilePosition thisPosition = new TilePosition(i, ColNo);
                Tile thisField = this.getTile(thisPosition);
                if (thisField == null) continue;
                this.removeTile(thisPosition);

                if (lastSeenTile!= null && thisField.value == lastSeenTile.value){
                    this.insertTile(new Tile(thisField.value*2), new TilePosition(movedTilesPosition, ColNo));
                    tilesOnBoard --;
                    i = movedTilesPosition;
                    lastSeenTile = null;
                }
                else{
                    movedTilesPosition -= 1;
                    this.insertTile(new Tile(thisField.value), new TilePosition(movedTilesPosition, ColNo));
                    lastSeenTile = thisField;
                }
            }
        }
    }

    public void makeGameMoveUp(){
        for (int ColNo = 0; ColNo<size; ColNo ++){
            Tile lastSeenTile = null;
            int movedTilesPosition = -1;

            int i = -1;
            while (i<size-1){
                i++;
                TilePosition thisPosition = new TilePosition(i, ColNo);
                Tile thisField = this.getTile(thisPosition);
                if (thisField == null) continue;
                this.removeTile(thisPosition);

                if (lastSeenTile!= null && thisField.value == lastSeenTile.value){
                    this.insertTile(new Tile(thisField.value*2), new TilePosition(movedTilesPosition, ColNo));
                    tilesOnBoard --;
                    i = movedTilesPosition;
                    lastSeenTile = null;
                }
                else{
                    movedTilesPosition += 1;
                    this.insertTile(new Tile(thisField.value), new TilePosition(movedTilesPosition, ColNo));
                    lastSeenTile = thisField;
                }
            }
        }
    }

}
