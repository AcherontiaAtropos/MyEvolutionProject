public class Tile {
    int value = 2;

    public Tile (int value){this.value = value;}
    public int getValue() {
        return value;
    }

    public String toString (){
        return String.valueOf(this.value);
    }
}
