public class GameOverException extends Exception {
    public GameOverException(String s)
    {
        super(s);
    }
}
