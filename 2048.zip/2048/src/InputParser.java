public class InputParser {
    public static Arrow stringToArrow (String s)
    throws IllegalArgumentException{
        switch (s) {
            case "left":
            case "L":
            case "LEFT":
            case "l": return Arrow.LEFT;
            case "right":
            case "r":
            case "RIGHT":
            case "R": return Arrow.RIGHT;
            case "up":
            case "UP":
            case "u":
            case "U": return Arrow.UP;
            case "down":
            case "d":
            case "DOWN":
            case "D": return Arrow.DOWN;

        }
        throw new IllegalArgumentException("Allowed input: \n \"left\",\"l\",\"right\",\"r\",\"up\",\"u\",\"down\" and \"d\"");
    }
}
