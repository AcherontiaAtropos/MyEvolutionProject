import java.util.Scanner;

public class ClassicGame {

    public static void play () {
        Scanner scanner = new Scanner(System.in);
        CenterBoard board = new CenterBoard(4);

        try {
            board.addRandomTile(2);
            board.addRandomTile(4);
        } catch (GameOverException e) {return;}

        System.out.print("Hello, lets play 2048! \n" +
                " Enter "+"\"left\",\"l\",\"right\",\"r\",\"up\",\"u\",\"down\" or \"d\"\n");

        Arrow nextMove;
        while (true){
            System.out.println(BoardVisualiser.drawBoard(board));
            System.out.println("Your next move: ");
            while (true){
                try {
                    nextMove = InputParser.stringToArrow(scanner.next());
                }catch (IllegalArgumentException e)
                {
                    System.out.print(e.getMessage());
                    continue;
                }
                break;
            }
            try {
                board.makeGameMove(nextMove);
            }catch (GameOverException e){
                System.out.println("GAME OVER \n Your score is:" + board.getScore());
            }
        }
    }
}
