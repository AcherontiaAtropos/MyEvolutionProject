enum Arrow {
    UP,
    DOWN,
    LEFT,
    RIGHT;

    Arrow parseToArrow(String s){
        switch (s){
            case "u":
                return UP;
            case "d":
                return DOWN;
            case "l":
                return LEFT;
            case "r":
                return RIGHT;
        }
        throw new IllegalArgumentException();
    }
}
