public class BoardVisualiser {

    public static String drawBoard(AbstractBoardClass board) {
        StringBuilder builder = new StringBuilder();
        builder.append(System.lineSeparator());
        for (int i = 0; i < board.getSize(); i++) {
            for (int j = 0; j<board.getSize(); j ++){
                String tileLetter = String.valueOf(board.getTile(new TilePosition(i,j)));
                if (tileLetter == "null") tileLetter = " ";
                builder.append('[' + tileLetter + ']');
            }
            builder.append('\n');
        }
        return builder.toString();
    }

    public static String drawBoard(FramedBoard framedBoard){
        Frame frame = framedBoard.frame;
        CenterBoard board = framedBoard.centerBoard;
        int size = board.getSize();
        if (frame.getSize() != size+2) return null;

        StringBuilder builder = new StringBuilder();

        for (int i = 0; i<size+2; i++){
            for (int j = 0; j<size+2; j++){
                AbstractBoardClass component = null;
                int x = i; int y = j;
                if (i*j==0 || (i-(size+1))*(j-(size+1))==0)
                    component = frame;
                else {
                    component = board;
                    x = i - 1; y = j-1;
                }
                String tileLetter = String.valueOf(component.getTile(new TilePosition(x, y)));
                if (tileLetter == "null") tileLetter = " ";
                builder.append('[' + tileLetter + ']');
            }
            builder.append('\n');
        }

    return builder.toString();
    }

}