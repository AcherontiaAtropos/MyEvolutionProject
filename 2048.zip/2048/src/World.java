import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class World {

    public static void main (String args[]) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Hello, World! Lets play 2048! There are two game modes. Type \"Classic\" or \"Frame\" : ");

        Set<String> modes = new HashSet<String>(Arrays.asList("Classic", "Frame"));

        String gameMode = scanner.next();;
        while (! modes.contains(gameMode)){
            System.out.println("Type \"Classic\" or \"Frame\', ok? ");
            gameMode = scanner.next();
        }

        switch (gameMode){
            case "Classic":
                ClassicGame.play(); return;
            case "Frame":
                FrameGame.play(); return;
        }


        /*
        // create a scanner so we can read the command-line input
        Scanner scanner = new Scanner(System.in);

        //  prompt for the user's name
        System.out.print("Enter your name: ");

        // get their input as a String
        String username = scanner.next();

        // prompt for their age
        System.out.print("Enter your age: ");

        // get the age as an int
        int age = scanner.nextInt();

        System.out.println(String.format("%s, your age is %d", username, age));

         */


    }
}
