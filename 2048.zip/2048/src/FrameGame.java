import java.util.Scanner;

public class FrameGame {

        public static void play () {
            Scanner scanner = new Scanner(System.in);
            CenterBoard centerBoard = new CenterBoard(4);
            Frame frame = new Frame(6, 16);
            FramedBoard board = new FramedBoard(frame, centerBoard);

            try {
                centerBoard.addRandomTile(2);
                centerBoard.addRandomTile(4);
            } catch (GameOverException e) {return;}

            System.out.print("Hello, lets play 2048! \n" +
                    " Enter "+"\"left\",\"l\",\"right\",\"r\",\"up\",\"u\",\"down\" or \"d\"\n");

            Arrow nextMove;
            while (true){
                System.out.println(BoardVisualiser.drawBoard(board));
                System.out.println("Your next move: ");
                while (true){
                    try {
                        nextMove = InputParser.stringToArrow(scanner.next());
                    }catch (IllegalArgumentException e)
                    {
                        System.out.print(e.getMessage());
                        continue;
                    }
                    break;
                }
                board.makeGameMove(nextMove);
            }
        }
}
