public class FramedBoard {

    Frame frame;
    CenterBoard centerBoard;
    int size;

    public FramedBoard (Frame frame, CenterBoard centerBoard){
        this.frame = frame;
        this.centerBoard = centerBoard;
        size = this.centerBoard.getSize();
    }

    public void makeGameMove (Arrow arrow){
        switch (arrow){
            case UP: makeGameMoveUp(); break;
            case LEFT: makeGameMoveLeft(); break;
            case DOWN: makeGameMoveDown(); break;
            case RIGHT: makeGameMoveRight();break;
        }
        try {
            int newTileValue = MyRand.getRandomNumberInRange(1,3)*2;
            this.centerBoard.addRandomTile(newTileValue);
        } catch (GameOverException e) {}

        this.frame.turnFrame();
    }

    public void makeGameMoveUp(){
        this.centerBoard.makeGameMoveUp();
        for (int i = 0; i<size; i++) {
            if (this.frame.getTile(new TilePosition(0, i + 1)) == null) {
                for (int j = 0; j < size; j++)
                    this.centerBoard.removeTile(new TilePosition(j, i));
            }
        }
    }
//DOWN
    public void makeGameMoveDown(){
        this.centerBoard.makeGameMoveDown();
        for (int i = 0; i<size; i++) {
            if (this.frame.getTile(new TilePosition(size+1, i + 1)) == null) {
                for (int j = 0; j < size; j++)
                    this.centerBoard.removeTile(new TilePosition(j, i));
            }
        }
    }
    //LEFT
    public void makeGameMoveLeft(){
        this.centerBoard.makeGameMoveLeft();
        for (int i = 0; i<size; i++) {
            if (this.frame.getTile(new TilePosition(i+1, 0)) == null) {
                for (int j = 0; j < size; j++)
                    this.centerBoard.removeTile(new TilePosition(i, j));
            }
        }
    }
    public void makeGameMoveRight(){
        this.centerBoard.makeGameMoveRight();
        for (int i = 0; i<size; i++) {
            if (this.frame.getTile(new TilePosition(i+1, size + 1)) == null) {
                for (int j = 0; j < size; j++)
                    this.centerBoard.removeTile(new TilePosition(i, j));
            }
        }
    }


}
