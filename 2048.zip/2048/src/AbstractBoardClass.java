public abstract class AbstractBoardClass {

    abstract Tile getTile(TilePosition tp);
    abstract int getSize ();

}
